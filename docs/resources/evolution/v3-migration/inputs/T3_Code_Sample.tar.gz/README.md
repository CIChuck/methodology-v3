# T3_Code_Sample

Python sample project with a local GenDev 1.0.2 development environment for T3 Code.

## Start a session

Read `AGENTS.md`, then run:

```sh
./scripts/gendev-doctor.sh
./scripts/project-state.sh
./scripts/check-methodology.sh
```

The project starts at **G1, pending**, in approval-gated mode. Chuck Russell is the project
owner, gate approver, and required human attester. The deployment approver remains unassigned.
Begin with `docs/project/vision/vision.md`; the other project artifacts are draft scaffolding.
No gate approvals or product implementation are established by this installation.

## Skills and methodology

The repository includes the GenDev constitution, guides, templates, role playbooks, and baseline
development skills. `.agents/skills/<name>/SKILL.md` entries use relative symlinks to canonical
sources under `docs/methodology/dev-skills/`, including the project-added skills. These links
remain valid in another checkout or Git worktree.
Start a fresh thread after installation to refresh skill discovery. If a provider does not
discover them, `AGENTS.md` points directly to the baseline guidance, and the added skills can be
read through their `SKILL.md` links.

The project-local policies in `docs/policies/` define engineering rules, task lifecycle,
independent validation, and a policy debt register. They use GenDev's existing project manifest,
gate log, and canonical artifact locations. AGENTS.md and the added skills reference these
policies. The task board tracks individual work items alongside GenDev's project/phase state;
task approval does not advance or bypass a GenDev gate.

Formal independent validation requires an approved scope, pinned authority, and a stable
candidate commit. The builder cannot verify its own candidate; `VERIFIED`, human acceptance,
and delivery remain distinct. Bounded documentation maintenance can use the recorded task
authorization and appropriate checks without claiming formal independent verification.

Product linting, typing, and test tools have not yet been selected. GenDev checks verify the
methodology environment; they do not establish product correctness. The policy debt register
records local observations and planning gaps rather than inherited package debt or error counts.

## Work-item board

The task registry is `docs/planning/board.yaml`; its generated view is
`docs/planning/README.md`. It starts empty, without imported tasks or approval history.
Use these commands from the repository root:

```sh
uv run --group devboard python scripts/devboard.py validate
uv run --group devboard python scripts/devboard.py next
uv run --group devboard python scripts/devboard.py list
uv run --group devboard python -m unittest discover -s tests/devboard -v
```

The `devboard` dependency group supplies PyYAML for this environment tooling; runtime product
dependencies remain separate. `scripts/friday-dev-board.py` is a compatibility symlink to
`scripts/devboard.py`. The linked `friday-dev-board` skill provides local operating guidance.
Use `docs/planning/task-template.md` to add a genuinely requested queued task, then render and
validate. The CLI does not create or move tracking folders.

The board checks recorded structure and transition constraints. It does not authenticate human
approvals, independently verify candidate reviews, reconcile remote delivery, or change GenDev
gates. See `docs/policies/dev-board-integration.md` and the local lifecycle policy for those
boundaries. Archive task tracking indexes only; canonical project authority stays in place.

The baseline was installed from the committed local `methodology-v2` revision
`cdf5c3ee1897bf26372d887a52ef8deeab82f20f`, which declares version 1.0.2. Uncommitted source
additions and optional reference resources were excluded. File hashes and upstream identity
are recorded in `docs/methodology/schema/installation.json`.

Approved local clarifications are recorded in `docs/policies/naa-implementation-choices.md`,
`docs/policies/architecture-amendment-impact.md`, and `docs/policies/rolling-wave-planning.md`.
The installation record preserves original and amended hashes, including prior effective
hashes when a file is amended again. Integrity checks use the approved effective content.
These clarifications do not change the upstream version.

Copied methodology material retains its upstream licenses, included in `docs/gendev-licenses/`.
This does not assign a license to the sample application's original code.

## T3 Code actions

`t3.json` declares GenDev Health, GenDev State, GenDev Validate, and GenDev Shell Check actions.
These are also registered in this machine's T3 project settings. GenDev Validate runs automatically
when T3 creates a worktree; it checks installation integrity and project coherence without
reinitializing the project. Import the actions from `t3.json` when registering another checkout
on another machine.

Dev Board Next and Dev Board Validate are also declared and registered for work-item tracking.

The effective local project default is GPT-6.1 Sol, high reasoning, with full access. These
machine settings are independent of GenDev's pending human approvals.

The repository currently has no commits. Make an initial commit before using Git worktrees;
the worktree needs the committed scaffold and skills.

## Checks

```sh
./scripts/gendev-doctor.sh
./scripts/check-methodology.sh
./scripts/test-methodology.sh --suite shell-syntax
```

`.github/workflows/methodology.yml` runs these product-context checks on pull requests and
pushes to `master` when the repository is hosted on GitHub. No remote or branch protection is
configured by this setup.
