def main():
    print("Hello from t3-code-sample!")


if __name__ == "__main__":
    main()
