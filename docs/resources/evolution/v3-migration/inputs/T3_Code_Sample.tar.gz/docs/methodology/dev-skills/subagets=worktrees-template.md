---
name: subagents-worktrees-template
description: Prepare an isolated worktree delegation plan when parallel subagent work is authorized. Define independent task ownership, GenDev authority, permitted effects, effort limits, and integration verification.
---

# Worktree Delegation Template

Prepare a plan for `[AUTHORIZED GOAL]` only when the user has authorized
parallel or isolated subagent work. A project setting or this template alone
does not request delegation.

Read `AGENTS.md`, `docs/project/project.yaml`, the applicable local policies,
and `docs/methodology/guides/subagent-coordination-protocol.md`. Establish the
current gate/checkpoint and accepted phase authority before assigning product
implementation. Worktrees require an initial commit.

## Assignment record

For each independent task, specify:

- phase and tactical task IDs;
- objective and approved construction directive;
- pinned authority paths and acceptance criteria;
- non-overlapping owned files and explicit non-goals;
- base revision and intended branch;
- required tests, evidence, and report paths;
- permitted external effects and commit/delivery authority;
- provider/model settings only when requested or inherited;
- effort limit, dependencies, integration order, and stop conditions.

If tasks overlap or required authority is missing, resolve ownership or return
the decision to the human before dispatch. Do not invent product architecture
to make a parallel split possible.

## T3 execution

For separate checkouts, use T3 `delegate_task` with `isolation: "worktree"`.
Call `orchestrator_capabilities` before the first delegate as required by the
active orchestration instructions. Put requested settings in `target.options`.
T3 owns checkout creation and binding; do not create a child's checkout in the
shell or in its assignment text. Do not launch top-level threads as subagents.

Same-provider synchronous work without separate checkout/settings may use a
native child. When independent review is required, give the reviewer fresh
context. Do not create additional review agents for a documentation-only
maintenance task unless authorized and justified by its scope.

Follow each running delegate's returned `next` instructions. Do not poll a
running delegate. Cancel a delegate that is replaced or no longer needed;
never silently switch an unavailable provider or model.

## Integration

Inspect each candidate and owned diff, preserve unrelated changes, and
integrate only under the applicable authority. Record integration and
verification evidence in the canonical project artifacts. Follow the
independent validation policy for the frozen integration candidate.

Subagent execution status is not project acceptance. Surface unresolved
conflicts; only the named human approves required scope, risk, and phase/gate
transitions. Push, merge, release, and deployment retain their separate
permission and evidence requirements.
