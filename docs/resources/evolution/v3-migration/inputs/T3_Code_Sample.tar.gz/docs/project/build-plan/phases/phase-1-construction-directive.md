# Phase 1 Construction Directive: T3_Code_Sample

Status: Draft
project: t3-code-sample
Date: 2026-10-27
Owner: TBD
Authority: docs/methodology/constitution/gendev.md
Source:
  Phase Build Plan: docs/project/build-plan/phases/phase-1-build-plan.md
  Tactical Plan: docs/project/build-plan/phases/phase-1-tactical-implementation-plan.md
  PRD: docs/project/prd/prd.md
  Architecture: docs/project/architecture/architecture.md
  Governance/Security: docs/project/security-governance/governance-security-spec.md
Produced by: TBD
Produced on: 2026-10-27
Produced with: human-agent collaboration
Agent identity: TBD
Derived from:
  - path: docs/project/build-plan/phases/phase-1-build-plan.md
    revision: TBD
  - path: docs/project/build-plan/phases/phase-1-tactical-implementation-plan.md
    revision: TBD
  - path: docs/project/prd/prd.md
    revision: TBD
  - path: docs/project/architecture/architecture.md
    revision: TBD
  - path: docs/project/security-governance/governance-security-spec.md
    revision: TBD

## Completion Standard

This directive is complete when it can be sent to an implementation agent as the controlling build
authority for Phase 1.

## AI Builder Role

You are implementing a bounded phase from documented authority. Implement only the scope authorized
by this directive and the tactical implementation plan.

## Source Authority And Precedence

1. docs/project/security-governance/governance-security-spec.md
2. docs/project/architecture/architecture.md
3. docs/project/prd/prd.md
4. docs/project/build-plan/phases/phase-1-build-plan.md
5. docs/project/build-plan/phases/phase-1-tactical-implementation-plan.md
6. This construction directive

## Implementation Objective

```text
Replace with the exact Phase 1 implementation objective.
```

## Allowed Scope

```text
Replace with authorized files, modules, behavior, tests, and documentation changes.
```

## Non-Goals

```text
List deferred and forbidden behavior. The implementation agent must not build these items.
```

## Required Workstreams

```text
Summarize tactical workstreams that must be implemented.
```

## Required Tests And Verification

```text
List required tests, UAT checks, verification commands, and expected evidence.
```

## Security And Governance Requirements

```text
List active security/governance constraints for this phase.
```

## Documentation Close-Out

```text
List docs that must be updated before phase close.
```

## Stop Conditions

Stop and request human or planning review if implementation requires new scope, architecture
changes, deferred behavior, unapproved external services, destructive migration, or changed
security/governance behavior.
