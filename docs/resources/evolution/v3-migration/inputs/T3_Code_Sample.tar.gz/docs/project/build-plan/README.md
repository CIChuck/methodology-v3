# Build Plan

Use this directory for build planning: the phase plan and phase-specific plans.

Phase plans live under:

```text
docs/project/build-plan/phases/
```
