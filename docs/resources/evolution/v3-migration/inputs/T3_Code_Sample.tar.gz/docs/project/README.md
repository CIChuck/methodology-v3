# T3_Code_Sample

This is the active project authority directory for T3_Code_Sample.

Start with the vision document, then move through PRD, architecture, governance/security,
phase planning, tactical implementation planning, construction directives, implementation,
review, remediation, and as-built close-out.

Controlling methodology:

```text
docs/methodology/constitution/gendev.md
```

Project manifest:

```text
docs/project/project.yaml
```

Current gate:

```text
G1 Vision Ready
```
