# Policy Debt Register

Status: Local operating policy
project: t3-code-sample
Date: 2026-10-27
Owner: Chuck Russell
Authority: AGENTS.md and docs/methodology/constitution/gendev.md
Produced by: Codex, under Chuck Russell's request to adapt these policies
Produced on: 2026-10-27
Produced with: human-agent collaboration
Agent identity: GPT-6.1 Sol via T3 Code
Derived from: user-supplied legacy-policy-debt.md, pre-adaptation SHA-256 bab195aac08b94d998bb5a65ca013be55c32f4a80416890a2d7283d2d85f0c81

## Purpose and scope

Track confirmed pre-existing violations of the local
[engineering policy](repository-engineering-policy.md) separately from new
regressions and from unmade project decisions. This register belongs to
T3_Code_Sample; imported package lists, historical error counts, and another
repository's remediation work do not describe this project's baseline.

No repository-wide policy or product audit has been completed. Absence of a
recorded finding does not establish compliance or independent verification.

## Confirmed baseline observations

### LPD-001: Sample entrypoint lacks an explicit return annotation

- Location: `main.py`, function `main`.
- Observation: the existing function is declared `def main():`.
- Applicable rule: explicit return annotations for new or materially changed
  public product functions under the engineering policy.
- Disposition: pre-existing sample scaffold; do not expand a documentation task
  into a product-code fix. Resolve when an authorized implementation change
  touches the entrypoint, or under a separately authorized bounded cleanup.
- Classification: baseline gap relative to the new-code standard, not a failed
  type-checker run or a retroactive implementation violation.
- Evidence: direct inspection of `main.py` on 2026-10-27; no static-analysis run
  or broader audit is claimed.
- Owner for disposition: Chuck Russell.
- Verification on remediation: the check selected by the accepted
  implementation/test plan and a review of the updated function contract.

## Readiness gaps, not measured debt

- Product linting, typing, and test tools have not been selected or declared.
  Define them through the stack decision and phase verification plan.
- Product implementation paths currently identify the existing entrypoint and
  environment files in the manifest. Extend them when the accepted architecture
  introduces new product paths; the current list does not predict that layout.
- The repository has no initial commit, so formal candidate review and Git
  worktrees are not yet available. Commit work only when authorized.
- Enforcement is attested. A checked-in workflow or optional hook installer is
  not evidence of an active protected-branch or local enforcement binding.

These are setup or planning facts, not failing product tests, accepted risk,
or permission to install tools or start implementation.

## Recording and resolving debt

For each new finding, record its ID, affected path, governing requirement,
reproducible evidence, risk/priority, owner, permitted next action, and required
verification. Mark the observation's date or revision. Distinguish an open
finding from an explicitly approved exception.

Close a finding only after the fix and required verification exist, or record
an explicit, scoped human exception with rationale and follow-up. Never replace
measurement with a guessed count, carry another repository's findings into
this baseline, or claim a finding closed because a workflow finished.
