# Development Board Integration

Status: Installed; functional checks passed
project: t3-code-sample
Date: 2026-10-27
Owner: Chuck Russell
Authority: AGENTS.md and docs/methodology/constitution/gendev.md
Produced by: Codex under Chuck Russell's task-board integration request
Produced on: 2026-10-27
Produced with: human-agent collaboration
Agent identity: GPT-6.1 Sol via T3 Code
Derived from: user-supplied board CLI and skill; original CLI SHA-256 e76cfbc383a71e5648e644a822835a102df813f2334eb8b8d4ddc897bc934ff4

Reference operating guidance: user-named agent-framework AGENTS.md, SHA-256
02c6360f0e2532a3ea761d7ae228fb105231c60d447146ead69c01c6ff99d152.
Matching imported schema: SHA-256
c0c7f22bc20bb40b2dfbdb066f7658f5de7518c2ece5e29870ec3e68f22eecbc.

## Authorized scope

Chuck Russell selected "Yes—task board alongside GenDev" on 2026-10-27.
Install a fresh local work-item tracker, its schema, tracking directories,
skill discovery, tooling dependency, T3 actions, and focused tests. Adapt
repository paths and operating instructions without importing another
repository's work items, approvals, accepted history, or measured debt.

This is development-environment integration. It does not authorize product
implementation at G1, make an initial commit, approve a product artifact,
advance a GenDev gate, or authorize external actions.

## Authority boundary

`docs/planning/board.yaml` owns individual task state, priority, dependency,
task-scoped authority, and recorded delivery state. Its generated README is a
view. `docs/project/project.yaml` and the gate log retain GenDev project,
phase, approval, and human-decision authority. Neither system overrides the
other's domain. A board task marked approved or granted does not permit work
that GenDev has not authorized. Its `next_gate` is a task instruction, not an
automatic project gate transition.

Planning lanes contain tracking indexes and bounded work-item evidence.
Canonical product authority stays at its existing `docs/project/` paths;
board acceptance or archival never moves those documents.

## Installation design

- Use `scripts/devboard.py` as the local CLI, with the supplied filename kept
  as a compatibility symlink.
- Preserve the imported validator and transition logic; limit code adaptation
  to repository naming and generated dashboard instructions/links.
- Install the matching version-1 schema and an empty board with no events.
- Keep required lane directories in Git using placeholder files.
- Declare PyYAML in the `devboard` tooling dependency group, separate from
  runtime product dependencies.
- Expose the supplied skill through its existing name and a relative symlink.
- Provide T3 actions for the next task and board validation.
- Leave the installed GenDev scripts, templates, and workflow unchanged.

## Validation and limits

Run board validation, read-only list/next commands, focused isolated-fixture
tests, skill metadata/link checks, GenDev doctor, and methodology coherence.
Exercise rejected agent approval/acceptance, missing branch/evidence,
dependencies, invalid transitions, stale dashboards, delivery requirements,
and preservation of GenDev state.

The board validates recorded structure and transition constraints. Actor-role
flags record the caller's declared role; they do not authenticate a human.
Validation does not independently prove human approval, formal VERIFIED
evidence, Git/hosting delivery, or accepted GenDev authority. The controller
must reconcile those facts under the local policies. Read-only board commands
do not replace GenDev orientation or product verification.

This setup remains uncommitted. Functional checks are not a formal independent
candidate review; that requires a frozen commit and separate review context.

## Setup results

On 2026-10-27:

- The board validated with zero tasks and no imported events; its generated
  dashboard was current and `next` returned `NO_OPEN_TASK`.
- Thirteen standard-library tests passed against isolated temporary boards.
  These cover declared-role approval/acceptance restrictions, branch and
  evidence requirements, transition/dependency constraints, stale dashboards,
  schema agreement, delivery requirements, and unchanged GenDev state.
- All fifteen skill manifests validated and their discovery links resolved,
  including the three relocated source files.
- GenDev doctor verified all 137 installed baseline files. Methodology
  coherence passed with zero warnings. The project remained at G1, pending.
- The product entrypoint, runtime project metadata, Python version, and
  GenDev manifest were unchanged; only the board tooling group was added to
  dependency configuration and its lockfile.
- AST comparison confirmed that imported validator and transition logic was
  unchanged; code adaptation was limited to the module description and
  generated dashboard text/links.
- All six checked-in T3 actions matched the registered project actions,
  including Dev Board Next and Dev Board Validate.

No independent candidate VERIFIED result, human task acceptance, GenDev gate
approval, commit, push, merge, or remote delivery reconciliation is claimed.
